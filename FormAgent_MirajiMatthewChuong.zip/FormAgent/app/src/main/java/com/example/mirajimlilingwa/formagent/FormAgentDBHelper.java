package com.example.mirajimlilingwa.formagent;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TableLayout;

/**
 * Created by mstch on 11/3/2017.
 */

public final class FormAgentDBHelper extends SQLiteOpenHelper {

    //If you change db scema, you must increment database version
    public static final int Database_Version = 1;
    public static final String Database_Name = "FormAgent.db";

    private static final String SQL_CREATE_ENTRIES = "Create Table" + DatabaseContract.TableLayout.Table_Name + " (" +
            DatabaseContract.TableLayout._ID + " Integer Primary Key," +
            DatabaseContract.TableLayout.Column_Name_Title + " Text," +
            DatabaseContract.TableLayout.Column_Name_Subtitle + " Text)";

    private static final String SQL_DELETE_ENTRIES = "Drop Table if exists " + DatabaseContract.TableLayout.Table_Name;

    public FormAgentDBHelper(Context context)
    {
        super(context, Database_Name, null, Database_Version);
    }

    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        onUpgrade(db, oldVersion, newVersion);
    }
}
