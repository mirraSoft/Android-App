package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class Succesful extends AppCompatActivity {

    FormAgentDBHelper db = Register.db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_succesful);

        String AgentCode = getIntent().getStringExtra("AgentCode");
        AdminObject current = db.getAdmin(AgentCode);

        String email = current.geteMail();

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, email);
        emailIntent.putExtra(Intent.EXTRA_CC, "formagent@gmail.com");
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Successful Registration FormAgent");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Here is a secret Code: CODE");

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
            finish();
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getApplicationContext(),
                    "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }
}
