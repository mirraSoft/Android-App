package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import static com.example.mirajimlilingwa.formagent.R.id.RegisterButton;

public class FormAgent extends AppCompatActivity {

    FormAgentDBHelper db = Register.db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_agent);

        EditText uname = (EditText) findViewById(R.id.Username);
        EditText pw = (EditText) findViewById(R.id.Password);
        final String user_name = uname.getText().toString();
        final String password = pw.getText().toString();


        Button LoginButton = (Button) findViewById(R.id.LoginButton);
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<AdminObject> admList = db.getAllAdminList();
                for(AdminObject adm : admList)
                {
                    //checks if exits in database
                    if(user_name.equals(adm.getUsername()) && password.equals(adm.getPassword()))
                        startActivity(new Intent(getApplicationContext(), AdminLogin.class));
                }
                Toast.makeText(getApplicationContext(), "Failed Login", Toast.LENGTH_LONG).show();
            }
        });



        Button regButton = (Button) findViewById(R.id.RegisterButton);
        //goes to Register Page
        regButton.setOnClickListener( new View.OnClickListener()//set Listener
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(getApplicationContext(), Register.class));
            }//OnClick
        }//View.OnClickListener
        ); //setOnClickListener
    }//OnCreate
}
