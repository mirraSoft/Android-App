package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Admin extends AppCompatActivity {

    FormAgentDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        db = new FormAgentDBHelper(this);

    }
}
