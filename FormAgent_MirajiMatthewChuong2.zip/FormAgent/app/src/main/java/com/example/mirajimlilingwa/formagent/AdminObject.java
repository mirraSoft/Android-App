package com.example.mirajimlilingwa.formagent;

/**
 * Created by mstch on 11/15/2017.
 */

public class AdminObject {
    int id;
    String Last_Name;
    String First_Name;
    String eMail;
    String Username;
    String Password;
    String Company_Name;
    String Company_Key;

    //empty constructor
    public AdminObject()
    {
    }
    //All parameters constructor
    public AdminObject(int _id, String LastName, String FirstName, String CompanyName, String CompanyKey, String pw, String mail, String uname)
    {
        id = _id;
        Last_Name = LastName;
        First_Name = FirstName;
        Company_Name = CompanyName;
        Company_Key = CompanyKey;
        eMail = mail;
        Username = uname;
        Password = pw;
    }
    //5 Parameter Constructor
    public AdminObject(String LastName, String FirstName, String uname, String email, String pw)
    {
        this.Last_Name = LastName;
        this.First_Name = FirstName;
        this.eMail = email;
        this.Password = pw;
        this.Username = uname;
    }
    //2 Parameter Constructor
    public AdminObject(String CompanyName, String CompanyKey)
    {
        Company_Name = CompanyName;
        Company_Key = CompanyKey;
    }
    public String getCompany_Key() {
        return Company_Key;
    }
    public void setCompany_Key(String company_Key) {
        Company_Key = company_Key;
    }

    public String getCompany_Name() {

        return Company_Name;
    }

    public void setCompany_Name(String company_Name) {
        Company_Name = company_Name;
    }

    public String getFirst_Name() {

        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public int getId() {

        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }


}
